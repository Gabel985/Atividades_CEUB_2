#include<stdio.h>
//Professor porque quando eu escrevo numero=numero2 o c�digo da errado
int main(){
	int numero, soma=0, UnidadeDezenaCentena_etc, numero2;
	printf("Digite um numero qualquer\n");
	scanf("%d", &numero);
	for(numero2=numero;numero2!=0;numero2=numero2/10){
	UnidadeDezenaCentena_etc=numero2%10;
	soma=soma+UnidadeDezenaCentena_etc;
	}
	printf("\nsoma = %d", soma);
}

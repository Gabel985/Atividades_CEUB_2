#include<stdio.h>
int main(){
	int numeroInicial, numeroFinal;
	printf("Digite o n�mero inicial\n");
	scanf("%d", &numeroInicial);
	printf("Digite o n�mero Final\n");
	scanf("%d", &numeroFinal);
	printf("\nSequencia dos numeros\n");
	for(numeroInicial!=numeroFinal;numeroInicial<=numeroFinal;numeroInicial++){
		printf("%d\n",numeroInicial);
	}
}

#include<stdio.h>
int main(){
	int numerosMedia, cont;
	float num, media=0.0;
	printf("Digite quantos n�meros reais para a m�dia ser realizada\n");
	scanf("%d", &numerosMedia);
	for(cont=numerosMedia;cont>0;cont--){
		printf(" \n Digite um numero: ");
		scanf("%f", &num);
		media+=num;
	}
	media = media/(float)numerosMedia;
	printf("\n A media dos numeros e %.2f", media);
	}
	
	

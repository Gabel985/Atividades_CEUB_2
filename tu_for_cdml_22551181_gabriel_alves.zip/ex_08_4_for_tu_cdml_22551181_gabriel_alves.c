#include<stdio.h>
int main(){
	float i, soma=0.0;
	scanf("%f", &i);
	for(i!=0.0;i>=1.0; i--){
	soma=soma+(1.0/i);
	}
	printf("soma dos numeros � igual a %.2f",soma);
}

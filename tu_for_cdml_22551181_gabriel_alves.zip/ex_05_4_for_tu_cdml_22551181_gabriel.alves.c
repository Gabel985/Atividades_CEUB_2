#include<stdio.h>
#include<stdlib.h>
int main(){
	float feet, metros;	
	printf("CONVERS�O PES PARA METROS\nMETROS	PES\n");
	for(metros=100;metros>=0;metros--){	
	feet=metros*3.261;
	printf("%.2f		%.2f\n", metros, feet);
	if((int)metros%20==0&&metros!=100){
		printf("aperta tecla para continuar");
		getchar();
		system("cls");
		printf("CONVERS�O FAHREINT CELSIUS\nmetros	pes\n");
		
	}
}
}


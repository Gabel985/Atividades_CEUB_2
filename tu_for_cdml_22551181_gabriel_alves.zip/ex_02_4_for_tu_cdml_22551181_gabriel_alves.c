#include<stdio.h>
int main(){
	int i=30, soma=0;
	for(i=30;i>=5; i--){
		if(i%3==0){
			printf("%d\n", i);
			soma=soma+i;
		}
	}
	printf("soma dos numeros � igual a %d",soma);
}

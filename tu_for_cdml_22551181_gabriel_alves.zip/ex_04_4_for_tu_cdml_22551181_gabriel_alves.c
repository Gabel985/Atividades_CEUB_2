#include<stdio.h>
#include<stdlib.h>
void main(void){
	float celsius, fahreint=50;	
	printf("CONVERS�O FAHREINT CELSIUS\n CELSIUS	FAHREINT\n");
	for(fahreint=50;fahreint>=-50;fahreint--){	
	celsius=(5.0/9.0)*(fahreint-32.0);
	printf("%.2f		%.2f\n", celsius, fahreint);
	if((int)fahreint%25==0&&fahreint!=50){
		printf("aperta tecla para continuar");
		getchar();
		system("cls");
		printf("CONVERS�O FAHREINT CELSIUS\n CELSIUS	FAHREINT\n");
		
	}
}
}

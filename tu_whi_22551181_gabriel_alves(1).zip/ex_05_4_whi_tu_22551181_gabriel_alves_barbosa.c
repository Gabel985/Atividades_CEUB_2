#include<stdio.h> 
int main(){ 
	int num,soma=0;
	printf("Digite um n�mero exceto -1\n"); 
	do{ 
	scanf("%d", &num); 
	soma+=num; 
	} 
	while(num!=-1); 
	soma=soma+1; 
	printf("\n A soma dos numeros � %d", soma);
	}

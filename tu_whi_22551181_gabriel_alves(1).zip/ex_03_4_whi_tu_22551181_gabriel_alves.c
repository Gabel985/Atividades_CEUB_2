#include<stdio.h>
int main(){
	float celsius, fahreint1, fahreint2;	
	printf("Digite a temperatura final e inicial em F\t\n");
	scanf("%f%f",&fahreint1,&fahreint2);
	printf("CONVERS�O FAHREINT CELSIUS\n CELSIUS	FAHREINT\n");
	while(fahreint1!=fahreint2){	
	celsius=(5.0/9.0)*(fahreint1-32.0);
	printf("%.2f		%.2f\n", celsius, fahreint1);
	if(fahreint1>=fahreint2){
	fahreint1--;
		}
		else{	
		if(fahreint1<=fahreint2)
		fahreint1++;					
}	
}
}



#include<stdio.h>
int main(){
	int numero;
	scanf("%d", &numero);
	while(numero!=1){
		numero--;
		printf("%d\n",numero);
	}
}

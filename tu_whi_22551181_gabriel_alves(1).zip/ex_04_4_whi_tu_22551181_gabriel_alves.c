#include<stdio.h>
int main(){
	int cont=50;
	float num, media=0.0;
	printf("Digite a nota dos alunos de 1 a 50\n");
	while(cont>0){
		printf(" \n Digite a nota do aluno %d: ",cont);
		scanf("%f", &num);
		media+=num;
		cont--;
	}
	media = media/(float)50;
	printf("\n A media dos numeros e %.2f", media);
	}

#include<stdio.h>
int main(){
	int cont=0;
	while(cont<10){
		cont++;
		printf("%d\n", cont);
	}
	printf("\n");
	while(cont!=0){
		cont--;
		printf("%d\n", cont);
	}
}

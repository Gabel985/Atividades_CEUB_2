#include<stdio.h>
int main(){
	float celsius, fahreint=32;
	printf("CONVERS�O FAHREINT CELSIUS\n CELSIUS	FAHREINT\n");
	while(fahreint<53){
		fahreint++;
		celsius=(5.0/9.0)*(fahreint-32.0);
		printf("%.2f		%.2f\n", celsius, fahreint);	
	}	
}

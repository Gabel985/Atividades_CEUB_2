#include<stdio.h> 
int main(){ 
int num, soma=0; 
printf("Digite um n�mero positivo\n"); 
do { scanf("%d", &num); 
soma+=num; 
printf("\n A soma dos numeros � %d\n", soma); 
} 
while(num>0); 
} 

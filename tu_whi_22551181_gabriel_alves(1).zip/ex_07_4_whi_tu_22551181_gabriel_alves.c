#include<stdio.h> 
int main(){ 
int numb, numeroTabuada=0, resultado;
printf("Digite um n�mero inteiro\n");
scanf("%d", &numb);
while(numeroTabuada<10){ 
numeroTabuada++; 
resultado = numeroTabuada * numb;
printf(" %d * %d = %d\n", numb, numeroTabuada, resultado);
} 
}

#include<stdio.h>
int main(){
	//Quest�o1
	float soma,a, b;
	printf("Digite dois n�meros para que se fa�a a soma: \n");
	scanf(" %f %f", &a, &b);
	soma = a + b;
	printf("SOMA: %.2f\n", soma);
	return 0;
}

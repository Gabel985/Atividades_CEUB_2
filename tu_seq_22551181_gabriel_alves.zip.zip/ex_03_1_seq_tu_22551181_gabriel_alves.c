#include<stdio.h> 
int main(){ 	
//quest�o3
	float area, h, base; 
	printf("Digite a altura e a base de um triangulo:\n"); 
	scanf(" %f %f", &h, &base); 
	area = (h * base) / 2; 
	printf("Esta � a area do tri�ngulo:\n %0.3f m^2, %.1f m, %.1f m", area, h, base); 
	return 0; 
}

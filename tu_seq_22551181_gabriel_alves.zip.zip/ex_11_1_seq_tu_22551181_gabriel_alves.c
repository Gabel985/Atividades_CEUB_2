#include<stdio.h>
int main(){//quest�o 11
	int a,b,c;
	printf("digite dois valores:\n");
	scanf(" %d %d", &a,&b);
	c=a;
	printf(" a=%d\n b=%d\n", a,b);
	a=b;b=c;
	printf(" a=%d\n b=%d\n", a,b);
	return 0;
}

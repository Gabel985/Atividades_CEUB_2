#include <stdio.h>
int main(){//quest�ao8
	float raio, pi, altura, arealat;
	pi=3.1415926;
	printf("Digite o raio e a altura de um cilindro:\n");
	scanf(" %f %f", &raio, &altura);
	arealat = 2 * pi * raio * altura;
	printf("Area lateral do cilindro: %.2f u.m^2\n\n", arealat);
	return 0;
}

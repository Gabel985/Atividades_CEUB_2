#include <stdio.h> 
//Quest�o 10 
int main() 
{   float a, b, raiz; 
	printf("Digite os coeficientes de uma equa��o de primeiro grau:");
 	scanf(" %f %f", &a,&b); 
 	raiz= (-b)/(a); 
 	printf("Raiz: %f", raiz); 
	 return 0; 
 }

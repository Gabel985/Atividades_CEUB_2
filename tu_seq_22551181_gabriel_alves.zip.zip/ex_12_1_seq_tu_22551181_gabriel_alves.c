#include<stdio.h>
int main(){//quest�o12
	float soma, sub, a, b;
	printf("Digite dois n�meros para que se fa�a a soma e subtra��o:\n");
	scanf(" %f %f", &a, &b);
	soma = a + b;
	printf("SOMA: %.1f\n", soma);
	sub = a - b;
	printf ("SUBTRA��O: %f.1\n", sub);
	return 0;
}

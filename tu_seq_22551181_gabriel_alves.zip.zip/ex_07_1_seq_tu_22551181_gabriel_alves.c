#include <stdio.h>
int main(){//questr�o 7
	float raio, pi, comp;
	pi=3.1415926;
	printf("Digite o raio de uma circunf�ncia:\n");
	scanf(" %f", &raio);
	comp = 2 * pi * raio;
	printf("Per�metro da circunferencia: %.2f u.m\n\n", comp);
	return 0;
}

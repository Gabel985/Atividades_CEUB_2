#include<stdio.h>
	int main(){//questao14
		float a, b, c, media;
		printf("Digite tres numeros reais para tirar a m�dia:\n");
		scanf(" %f %f %f", &a, &b, &c);
		media=(a+b+c)/3;
		printf("M�dia: %0.2f\n", media);
		return 0;
		
	}

#include<stdio.h>
int main(){
	//quest�o 2
	int soma, mult, sub, a, b;
	printf("Digite dois n�meros para que se fa�a a soma, multiplica��o e subtra��o:\n");
	scanf(" %d %d", &a, &b);
	soma = a + b;
	printf("SOMA: %d\n", soma);
	mult = a * b;
	printf("PRODUTO: %d\n", mult);
	sub = a - b;
	printf ("SUBTRA��O: %d\n", sub);
	return 0;
}

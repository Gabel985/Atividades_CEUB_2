#include <stdio.h>
int main(){//quest�o9
	float r, pi, vol;
	pi=3.1415926;
	printf("Digite o raio de uma esfera:\n");
	scanf(" %f", &r);
	vol = (4 * pi * r * r * r)/3;
	printf("Volume: %.2f u.m^3\n\n", vol);
	return 0;
}

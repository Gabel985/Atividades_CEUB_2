#include <stdio.h>
int main()//quest�o13
{   float metros, pes;
        printf("Digite p�s para convertes para metros:\n");
        scanf(" %f", &pes);
        metros  = pes * 0.3048;
        printf("metros: %.2f m\n", metros);
        return 0;
}

#include <stdio.h>
int main(){//quest�o 6
	float raio, pi, area;
	pi=3.1415926;
	printf("Digite o raio de uma circunf�ncia:\n");
	scanf(" %f", &raio);
	area=pi*raio*raio;
	printf("Area: %.2f u.m^2\n\n", area);
	return 0;
}

#include<stdio.h> 
int main(){
	//quest�o4
	float media, nota1, nota2; 
	printf("Digite as notas bimestrais do aluno:\n"); 
	scanf(" %f %f", &nota1, &nota2); 
	media = (nota1 + nota2) / 2; 
	printf("Esta � a m�dia:\n %0.2f,\n Estas s�o as notas: \n  %0.2f, %0.2f", media, nota1, nota2); 
	return 0; 
}

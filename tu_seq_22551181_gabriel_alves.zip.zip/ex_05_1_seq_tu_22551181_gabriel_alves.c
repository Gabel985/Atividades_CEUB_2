#include<stdio.h>
	int main(){
		//quest�o5
		float faheit, celsius;
		printf("Digite a temperatura em Fahrenheit:\n");
		scanf(" %f", &faheit);
		celsius = (faheit - 32) / 1.8;
		printf("A temperatura em celsius �:\n %.0f �C", celsius);
		return 0;
	}

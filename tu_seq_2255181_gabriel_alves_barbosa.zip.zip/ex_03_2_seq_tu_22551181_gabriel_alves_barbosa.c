#include<stdio.h>
int main(){
	float n1, multp;
	printf("\n Digite um numero real \n");
	scanf("%f", &n1);
	if(n1>0){
		multp= n1*2;
		printf("O numero %.1f e positivo e seu dobro e %.1f", n1, multp);
		}
		else
			if(n1==0){
				printf("O n�mero e nulo");}
				else{
					multp=n1*3;
					printf("O numero %.1f e negativo e seu triplo e %.1f", n1, multp);}

	return 0;
	}

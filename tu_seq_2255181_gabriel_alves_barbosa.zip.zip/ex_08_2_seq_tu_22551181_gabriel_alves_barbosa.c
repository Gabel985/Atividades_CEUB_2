#include<stdio.h>
int main(){
	float a;
	printf("Escolha um numero qualquer para verificar se e maior que 100\n");
	scanf("%f", &a);
	if(a>100){
		printf("O numero %.0f e maior que 100", a);
	}
		else
			if(a==100){
			printf("o numero %.0f e igual 100", a);}
				else
				printf("O numero %.0f e menor que 100", a);
	return 0;
}

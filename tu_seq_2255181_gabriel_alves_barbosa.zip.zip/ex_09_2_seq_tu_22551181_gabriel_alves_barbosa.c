
#include<stdio.h>
#include<math.h>
int main(){
	int a, b, c, pot;
	float x1,x2, delta,raizDelta;
	printf("Digite os coeficientes de uma equa�ao de segundo grau para verificar a existencia de raizes\n");
	scanf("%d%d%d",&a, &b, &c);
	pot=pow(b,2);
	delta=(pot-4*a*c);
	raizDelta=sqrt(delta);
	x1=(-b+raizDelta)/(2*a);
	x2=(-b-raizDelta)/(2*a);
	if(delta>0){
		printf("A equa��o %dx^2 +%dx +%d possui como raiz os numeros: %.2f, %.2f",a,b,c,x1,x2);
	}
		else
			if(delta<0){
				printf("A equa��o %dx2 +%dx +%d n�o possui ra�z nos n�meros reais", a,b,c);
			}
			else{
				printf("A equa��o %dx2 +%dx +%d possui %.2f como raiz", a,b,c, x1);
	}return 0;	
}

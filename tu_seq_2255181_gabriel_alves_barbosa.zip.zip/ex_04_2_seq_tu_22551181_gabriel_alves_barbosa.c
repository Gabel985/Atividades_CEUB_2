#include<stdio.h>
int main(){
	float altura, peso;
	char sexo;
	printf("Qual o seu sexo, m ou f?\n");
	scanf("%c",&sexo);
	printf("Qual a sua altura?\n");
	scanf("%f", &altura);
	if(sexo=='m'||sexo=='M'){
		peso=((72.7*altura)-58);
		printf("Seu peso ideal e %.2f e voce e homem", peso);}
			else
				if(sexo=='f'||sexo=='F'){
				peso=((62.1*altura)-44.7);
				printf("Seu peso ideal e %.2f e voce e mulher", peso);}
					else
					printf("Erro");
	return 0;
}

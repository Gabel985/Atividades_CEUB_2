#include<stdio.h>
int main(){
	float n1, n2;
	printf("\n Digite dois n�meros reais \n");
	scanf("%f %f", &n1, &n2);
	if(n1>n2){
		printf("O n�mero %.2f � maior que o n�mero %.2f", n1, n2);}
		else
			if(n1==n2){
				printf("Os n�meros s�o iguais");}
				else
				if(n1<n2){
		printf("O n�mero %.1f � maior que o numero %.1f", n2,n1);}
	return 0;
	}


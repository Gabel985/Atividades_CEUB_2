#include<stdio.h>
int main(){
	float gastos, vendas, balanco;
	printf("\n Digite os seus gastos e sua fatura \n");
	scanf("%f %f", &gastos, &vendas);
	if(gastos>vendas){
		balanco=gastos - vendas;
		printf("Houve prejuizo de %.2f R$,\ngastos: %.2fR$, \nvendas:%.2fR$", balanco, gastos, vendas);}
		else
			if(vendas=gastos){
				printf("Os valores s�o iguais,\ngastos: %.2fR$, \nvendas:%.2fR$", gastos, vendas);}
				else
				if(vendas>gastos){
					balanco=vendas-gastos;
					printf("Houve lucro de  %.2f R$\n,gastos: %.2fR$\n, vendas:%.2fR$\n", balanco, gastos, vendas);}
	return 0;
}

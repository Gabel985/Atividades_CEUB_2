#include<stdio.h>
int main(){
	int idade, ano;
	printf("Qual o seu ano de nascimento\n");
	scanf("%d", &ano);
	idade=2025-ano;
	if(idade>=16){
		printf("Voc� nasceu em %d, tem %d anos e pode votar", ano,idade);
	}
	else
		printf("Voc� nasceu em %d.tem %d anos e n�o pode votar",ano,idade);
	return 0;
}


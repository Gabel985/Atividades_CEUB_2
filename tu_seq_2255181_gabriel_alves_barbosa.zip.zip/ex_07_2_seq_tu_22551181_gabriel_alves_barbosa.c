#include<stdio.h> 
int main(){
	float media, nota1, nota2;
	int peso1, peso2;
	printf("Digite as notas bimestrais do aluno:\n"); 
	scanf("%f %f", &nota1, &nota2); 
	printf("Digite os pesos das notas:\n"); 
	scanf("%d %d", &peso1, &peso2);
	media = ((nota1*peso1) + (nota2*peso2))/ (peso1+peso2); 
	if(media>=5){
		printf("O aluno foi aprovado com media %.2f", media);
	}
			else
			printf("O aluno foi reprovado com media %.2f", media);
	return 0;
}

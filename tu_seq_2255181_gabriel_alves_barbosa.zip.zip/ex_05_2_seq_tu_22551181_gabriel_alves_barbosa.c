#include<stdio.h>
int main(){
	int a;
	printf("Escolha um numero qualquer para verificar se e par ou impar\n");
	scanf("%d", &a);
	if(a%2==0){
		printf("O numero %d e par", a);
	}
		else
		printf("o numero %d e impar", a);
	return 0;
}
